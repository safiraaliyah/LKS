<?php echo $__env->make('components.header', ['editProfil' => 'editProfil / LKS'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Profile</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="max-w-4xl mx-auto mt-10 bg-white p-6 rounded-lg shadow-lg">
        <h1 class="text-2xl font-bold mb-6">Edit Profile</h1>
        <form class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Upload Foto (.JPG, .SVG, .RAW)</label>
                <div class="md:col-span-2">
                    <input type="file" accept=".jpg,.svg,.raw" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Nama LKS</label>
                <div class="md:col-span-2">
                    <input type="text" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Ketua LKS</label>
                <div class="md:col-span-2">
                    <input type="text" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Alamat LKS</label>
                <div class="md:col-span-2">
                    <input type="text" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-2 text-gray-700">Nomor & Tanggal Akte Notaris</label>
                <div class="md:col-span-2 space-y-2">
                    <input type="text" placeholder="Nomor Notaris" class="w-full p-2 border border-gray-300 rounded-lg">
                    <input type="date" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Nomor & Tanggal Tanda Daftar</label>
                <div class="md:col-span-2 space-y-2">
                    <input type="text" placeholder="Nomor Daftar" class="w-full p-2 border border-gray-300 rounded-lg">
                    <input type="datetime-local" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Kontak Pengurus</label>
                <div class="md:col-span-2">
                    <input type="text" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Akreditasi</label>
                <div class="md:col-span-2">
                    <input type="text" class="w-full p-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Jenis LKS</label>
                <div class="md:col-span-2">
                    <select class="w-full p-2 border border-gray-300 rounded-lg">
                        <option>LKS Kota</option>
                        <option>LKS Provinsi</option>
                        <option>LKS Nasional</option>
                    </select>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4">
                <label class="md:text-left pr-4 text-gray-700">Jenis Pelayanan</label>
                <div class="md:col-span-2">
                    <select class="w-full p-2 border border-gray-300 rounded-lg">
                        <option>Anak</option>
                        <option>Disabilitas</option>
                        <option>Lanjut Usia</option>
                    </select>
                </div>
            </div>
            <div class="flex justify-end mt-4">
                <a href="/profil" class="mr-2 bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</a>
                <a href="/profil" class="bg-[#08A78B]  text-white px-4 py-2 rounded-lg hover:bg-[#114138]">Simpan</a>
            </div>
        </form>
    </div>
</body>
</html>
<?php echo $__env->make('components.footer', ['editProfil' => 'editProfil / LKS'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Safira Aliyah Azmi\Documents\web\lks\resources\views/editProfil.blade.php ENDPATH**/ ?>