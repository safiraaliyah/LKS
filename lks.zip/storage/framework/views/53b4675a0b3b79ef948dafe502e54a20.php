<?php echo $__env->make('components.header', ['profil' => 'profil / LKS'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($profil->nama); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href='https://unicons.iconscout.com/release/v4.0.0/css/line.css' rel='stylesheet'>
</head>
<body class="bg-gray-100">
    <div class="max-w-6xl mx-auto p-6">
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <!-- Bagian Profil -->
        <div class="bg-white rounded-lg shadow-lg p-8 mb-6">
            <div class="flex flex-col md:flex-row items-center">
                <?php if($profil->image): ?>
                    <img src="<?php echo e(Storage::url($profil->image)); ?>" alt="<?php echo e($profil->nama); ?>" class="w-full md:w-1/2 h-64 object-cover rounded-lg mb-6 md:mb-0 md:mr-8">
                <?php else: ?>
                    <img src="<?php echo e(asset('panti3.jpg')); ?>" alt="<?php echo e($profil->nama); ?>" class="w-full md:w-1/2 h-64 object-cover rounded-lg mb-6 md:mb-0 md:mr-8">
                <?php endif; ?>
                <div class="w-full md:w-1/2">
                    <h1 class="text-3xl font-bold mb-4"><?php echo e($profil->nama); ?></h1>
                    <p class="text-lg flex items-center mb-2"><i class="uil uil-user mr-2"></i><strong>Ketua LKS:</strong> <?php echo e($profil->ketua); ?></p>
                    <p class="text-lg flex items-center mb-2"><i class="uil uil-map-marker mr-2"></i><strong>Alamat LKS:</strong> <?php echo e($profil->alamat); ?></p>
                    <p class="text-lg flex items-center mb-2"><i class="uil uil-phone mr-2"></i><strong>Kontak Pengurus:</strong> <?php echo e($profil->kontak); ?></p>
                </div>
            </div>
        </div>

        <!-- Bagian Tentang -->
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-2xl font-bold mb-6">About</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <p class="text-lg"><strong>Nomor & Tanggal Akte Notaris:</strong><br><?php echo e($profil->nomor_notaris); ?>, Tanggal: <?php echo e(\Carbon\Carbon::parse($profil->tanggal_notaris)->format('d F Y')); ?></p>
                    <p class="text-lg"><strong>Nomor & Tanggal Tanda Daftar:</strong><br><?php echo e($profil->nomor_daftar); ?>, Tanggal: <?php echo e(\Carbon\Carbon::parse($profil->tanggal_daftar)->format('d F Y H:i')); ?></p>
                    <p class="text-lg"><strong>Akreditasi:</strong><br><?php echo e($profil->akreditasi); ?></p>
                </div>
                <div>
                    <p class="text-lg"><strong>Jenis LKS:</strong><br><?php echo e($profil->jenis_lks); ?></p>
                    <p class="text-lg"><strong>Jenis Pelayanan:</strong><br><?php echo e($profil->jenis_pelayanan); ?></p>
                </div>
            </div>
        </div>
        
        <!-- Tombol Edit Profil dan Kembali -->
        <div class="flex justify-center mt-6 space-x-4">
            <a href="<?php echo e(url('/editProfil/' . $profil->id)); ?>" class="bg-[#08A78B] hover:bg-[#114138] text-white font-bold py-2 px-4 rounded">
                Edit Profile
            </a>
            <a href="<?php echo e(url('/')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                Kembali
            </a>
        </div>
    </div>
</body>
</html>
<?php echo $__env->make('components.footer', ['profil' => 'profil / LKS'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Safira Aliyah Azmi\Documents\web\lks\resources\views/profil.blade.php ENDPATH**/ ?>